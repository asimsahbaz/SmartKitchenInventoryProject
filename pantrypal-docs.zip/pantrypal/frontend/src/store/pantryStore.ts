/**
 * store/pantryStore.ts
 *
 * Zustand store for pantry state management.
 *
 * ARCHITECTURE ROLE: State Management Layer (Client)
 *
 * This store is the single source of truth for pantry data on the frontend.
 * It owns:
 *  - The list of pantry items
 *  - Active filter state
 *  - Loading and error states
 *  - Actions that call the API and update state
 *
 * WHY ZUSTAND (see ADR-002):
 * Simple API, no boilerplate. The store is a plain TypeScript object —
 * easy to read, easy to test, and works seamlessly with TypeScript.
 */

import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { pantryApi } from '../api/pantry.api';

// ─── Types ────────────────────────────────────────────────────────────────────

export type ExpiryStatus = 'FRESH' | 'EXPIRING_SOON' | 'EXPIRED' | 'NO_EXPIRY';

export interface PantryItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  category: { id: string; name: string; icon: string | null } | null;
  expiryDate: string | null;
  expiryStatus: ExpiryStatus;
  addedAt: string;
  notes: string | null;
}

export interface PantryFilters {
  search: string;
  categoryId: string;
  status: ExpiryStatus | '';
  sortBy: 'name' | 'expiryDate' | 'addedAt' | 'quantity';
  sortOrder: 'asc' | 'desc';
}

export interface CreatePantryItemDto {
  name: string;
  quantity: number;
  unit: string;
  categoryId?: string;
  expiryDate?: string;
  notes?: string;
}

// ─── Store ────────────────────────────────────────────────────────────────────

interface PantryStore {
  items: PantryItem[];
  total: number;
  filters: PantryFilters;
  isLoading: boolean;
  error: string | null;

  // Actions
  fetchItems: () => Promise<void>;
  addItem: (dto: CreatePantryItemDto) => Promise<void>;
  updateItem: (id: string, dto: Partial<CreatePantryItemDto>) => Promise<void>;
  deleteItem: (id: string) => Promise<void>;
  setFilters: (filters: Partial<PantryFilters>) => void;
  clearError: () => void;
}

const defaultFilters: PantryFilters = {
  search: '',
  categoryId: '',
  status: '',
  sortBy: 'addedAt',
  sortOrder: 'desc',
};

export const usePantryStore = create<PantryStore>()(
  devtools(
    (set, get) => ({
      items: [],
      total: 0,
      filters: defaultFilters,
      isLoading: false,
      error: null,

      fetchItems: async () => {
        set({ isLoading: true, error: null });
        try {
          const { filters } = get();
          const result = await pantryApi.getAll(filters);
          set({ items: result.data, total: result.meta.total, isLoading: false });
        } catch (err: any) {
          set({ error: err.message ?? 'Failed to load pantry items.', isLoading: false });
        }
      },

      addItem: async (dto) => {
        set({ isLoading: true, error: null });
        try {
          await pantryApi.create(dto);
          await get().fetchItems(); // Refresh list after creation
        } catch (err: any) {
          set({ error: err.message ?? 'Failed to add item.', isLoading: false });
          throw err; // Re-throw so form can handle validation errors
        }
      },

      updateItem: async (id, dto) => {
        set({ isLoading: true, error: null });
        try {
          await pantryApi.update(id, dto);
          await get().fetchItems();
        } catch (err: any) {
          set({ error: err.message ?? 'Failed to update item.', isLoading: false });
          throw err;
        }
      },

      deleteItem: async (id) => {
        // Optimistic removal from UI before server confirms
        const previous = get().items;
        set(state => ({ items: state.items.filter(i => i.id !== id) }));

        try {
          await pantryApi.delete(id);
        } catch (err: any) {
          // Rollback on failure
          set({ items: previous, error: 'Failed to delete item.' });
        }
      },

      setFilters: (newFilters) => {
        set(state => ({ filters: { ...state.filters, ...newFilters } }));
        get().fetchItems(); // Refetch with new filters
      },

      clearError: () => set({ error: null }),
    }),
    { name: 'pantry-store' }, // DevTools label
  ),
);
