/**
 * store/authStore.ts
 *
 * Zustand store for authentication state.
 *
 * SECURITY DESIGN (see ADR-003):
 * - Access token stored in memory (this store), NOT localStorage
 * - Refresh token is in HTTP-only cookie, managed by the browser
 * - On page refresh, the access token is lost — we call /auth/refresh to get a new one
 */

import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { authApi } from '../api/auth.api';
import { apiClient } from '../api/apiClient';

export interface AuthUser {
  id: string;
  email: string;
  role: 'REGULAR_USER' | 'ADMIN';
}

interface AuthStore {
  user: AuthUser | null;
  accessToken: string | null;
  isAuthenticated: boolean;
  isInitializing: boolean; // True during the initial token refresh on app load

  // Actions
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  initAuth: () => Promise<void>; // Called on app mount to restore session
  setAccessToken: (token: string) => void; // Used by the Axios interceptor on refresh
}

export const useAuthStore = create<AuthStore>()(
  devtools(
    (set, get) => ({
      user: null,
      accessToken: null,
      isAuthenticated: false,
      isInitializing: true,

      login: async (email, password) => {
        const { data } = await authApi.login({ email, password });
        // Store access token in memory; cookie is set by the server automatically
        apiClient.defaults.headers.common['Authorization'] = `Bearer ${data.accessToken}`;
        set({
          user: data.user,
          accessToken: data.accessToken,
          isAuthenticated: true,
        });
      },

      register: async (email, password) => {
        const { data } = await authApi.register({ email, password });
        apiClient.defaults.headers.common['Authorization'] = `Bearer ${data.accessToken}`;
        set({
          user: data.user,
          accessToken: data.accessToken,
          isAuthenticated: true,
        });
      },

      logout: async () => {
        try {
          await authApi.logout(); // Clears HTTP-only cookie server-side
        } finally {
          delete apiClient.defaults.headers.common['Authorization'];
          set({ user: null, accessToken: null, isAuthenticated: false });
        }
      },

      /**
       * Called once on app mount to restore the session from the refresh token cookie.
       * If the cookie is valid, we get a new access token silently.
       * If not, the user sees the login page.
       */
      initAuth: async () => {
        try {
          const { data } = await authApi.refresh();
          apiClient.defaults.headers.common['Authorization'] = `Bearer ${data.accessToken}`;
          const { data: meData } = await authApi.me();
          set({
            user: meData,
            accessToken: data.accessToken,
            isAuthenticated: true,
            isInitializing: false,
          });
        } catch {
          // Refresh failed — user is not authenticated, show login
          set({ isAuthenticated: false, isInitializing: false });
        }
      },

      setAccessToken: (token) => {
        apiClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        set({ accessToken: token });
      },
    }),
    { name: 'auth-store' },
  ),
);
