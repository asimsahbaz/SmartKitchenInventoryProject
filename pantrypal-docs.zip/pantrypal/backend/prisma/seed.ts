/**
 * prisma/seed.ts
 *
 * Seeds the database with initial data for local development.
 * Run with: npm run db:seed
 */

import { PrismaClient, UserRole } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // ── Categories ──────────────────────────────────────────────────────────────
  const categories = await Promise.all([
    prisma.category.upsert({ where: { name: 'Dairy' }, update: {}, create: { name: 'Dairy', icon: '🥛' } }),
    prisma.category.upsert({ where: { name: 'Vegetables' }, update: {}, create: { name: 'Vegetables', icon: '🥦' } }),
    prisma.category.upsert({ where: { name: 'Fruits' }, update: {}, create: { name: 'Fruits', icon: '🍎' } }),
    prisma.category.upsert({ where: { name: 'Meat & Fish' }, update: {}, create: { name: 'Meat & Fish', icon: '🥩' } }),
    prisma.category.upsert({ where: { name: 'Grains & Pasta' }, update: {}, create: { name: 'Grains & Pasta', icon: '🌾' } }),
    prisma.category.upsert({ where: { name: 'Condiments' }, update: {}, create: { name: 'Condiments', icon: '🧴' } }),
    prisma.category.upsert({ where: { name: 'Snacks' }, update: {}, create: { name: 'Snacks', icon: '🍿' } }),
    prisma.category.upsert({ where: { name: 'Beverages' }, update: {}, create: { name: 'Beverages', icon: '🧃' } }),
    prisma.category.upsert({ where: { name: 'Frozen' }, update: {}, create: { name: 'Frozen', icon: '🧊' } }),
    prisma.category.upsert({ where: { name: 'Other' }, update: {}, create: { name: 'Other', icon: '📦' } }),
  ]);
  console.log(`✅ Created ${categories.length} categories`);

  // ── Admin User ──────────────────────────────────────────────────────────────
  const adminPassword = await bcrypt.hash('admin123!', 12);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@pantrypal.local' },
    update: {},
    create: {
      email: 'admin@pantrypal.local',
      passwordHash: adminPassword,
      role: UserRole.ADMIN,
    },
  });
  console.log(`✅ Admin user: ${admin.email} (password: admin123!)`);

  // ── Demo User ───────────────────────────────────────────────────────────────
  const userPassword = await bcrypt.hash('user123!', 12);
  const demoUser = await prisma.user.upsert({
    where: { email: 'demo@pantrypal.local' },
    update: {},
    create: {
      email: 'demo@pantrypal.local',
      passwordHash: userPassword,
      role: UserRole.REGULAR_USER,
    },
  });
  console.log(`✅ Demo user: ${demoUser.email} (password: user123!)`);

  // ── Sample Recipes ──────────────────────────────────────────────────────────
  const tomatoSoupRecipe = await prisma.recipe.upsert({
    where: { id: 'recipe-tomato-soup-seed' },
    update: {},
    create: {
      id: 'recipe-tomato-soup-seed',
      title: 'Classic Tomato Soup',
      description: 'A warming, simple tomato soup perfect for a quick weeknight dinner.',
      instructions: '1. Dice the onion and garlic.\n2. Sauté in olive oil for 5 minutes.\n3. Add tomatoes and stock.\n4. Simmer for 20 minutes.\n5. Blend until smooth.\n6. Season and serve.',
      servings: 4,
      prepTimeMinutes: 30,
      ingredients: {
        create: [
          { ingredientName: 'Tomatoes', quantity: 6, unit: 'pcs' },
          { ingredientName: 'Onion', quantity: 1, unit: 'pcs' },
          { ingredientName: 'Garlic', quantity: 3, unit: 'pcs' },
          { ingredientName: 'Olive Oil', quantity: 2, unit: 'tbsp' },
          { ingredientName: 'Vegetable Stock', quantity: 500, unit: 'ml' },
        ],
      },
    },
  });

  const pastaRecipe = await prisma.recipe.upsert({
    where: { id: 'recipe-pasta-aglio-seed' },
    update: {},
    create: {
      id: 'recipe-pasta-aglio-seed',
      title: 'Pasta Aglio e Olio',
      description: 'A classic Italian pasta dish with garlic, olive oil, and parsley.',
      instructions: '1. Cook pasta according to package instructions.\n2. Sauté garlic in olive oil.\n3. Add cooked pasta and pasta water.\n4. Toss with parsley and chili flakes.\n5. Serve immediately.',
      servings: 2,
      prepTimeMinutes: 20,
      ingredients: {
        create: [
          { ingredientName: 'Spaghetti', quantity: 200, unit: 'g' },
          { ingredientName: 'Garlic', quantity: 4, unit: 'pcs' },
          { ingredientName: 'Olive Oil', quantity: 4, unit: 'tbsp' },
          { ingredientName: 'Parsley', quantity: 1, unit: 'tbsp' },
          { ingredientName: 'Chili Flakes', quantity: 0.5, unit: 'tsp' },
        ],
      },
    },
  });
  console.log(`✅ Created 2 sample recipes`);

  // ── Demo Pantry Items ───────────────────────────────────────────────────────
  const today = new Date();
  const in2Days = new Date(today.getTime() + 2 * 24 * 60 * 60 * 1000);
  const in10Days = new Date(today.getTime() + 10 * 24 * 60 * 60 * 1000);
  const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);

  await prisma.pantryItem.createMany({
    data: [
      { userId: demoUser.id, categoryId: categories[0].id, name: 'Whole Milk', quantity: 1, unit: 'l', expiryDate: in2Days, notes: 'Organic' },
      { userId: demoUser.id, categoryId: categories[1].id, name: 'Tomatoes', quantity: 6, unit: 'pcs', expiryDate: in10Days },
      { userId: demoUser.id, categoryId: categories[1].id, name: 'Onion', quantity: 3, unit: 'pcs', expiryDate: in10Days },
      { userId: demoUser.id, categoryId: categories[1].id, name: 'Garlic', quantity: 1, unit: 'pcs', expiryDate: in10Days },
      { userId: demoUser.id, categoryId: categories[4].id, name: 'Spaghetti', quantity: 500, unit: 'g' },
      { userId: demoUser.id, categoryId: categories[5].id, name: 'Olive Oil', quantity: 750, unit: 'ml' },
      { userId: demoUser.id, categoryId: categories[0].id, name: 'Yogurt', quantity: 500, unit: 'g', expiryDate: yesterday },
    ],
    skipDuplicates: true,
  });
  console.log(`✅ Created demo pantry items for ${demoUser.email}`);

  console.log('\n🎉 Seed complete!');
  console.log('   Admin:    admin@pantrypal.local / admin123!');
  console.log('   Demo:     demo@pantrypal.local / user123!');
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
