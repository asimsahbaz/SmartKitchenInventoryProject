/**
 * app.ts
 *
 * Express application setup and middleware configuration.
 *
 * ARCHITECTURE NOTE:
 * This file is the composition root for the backend.
 * It wires together: middleware → routes → error handling.
 * The order of middleware registration in Express is critically important.
 */

import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import swaggerUi from 'swagger-ui-express';
import YAML from 'yamljs';
import path from 'path';

import { globalErrorHandler } from './shared/middleware/errorHandler';
import { authRouter } from './features/auth/auth.routes';
import { pantryRouter } from './features/pantry/pantry.routes';
import { recipeRouter } from './features/recipes/recipe.routes';
import { shoppingListRouter } from './features/shopping-list/shopping-list.routes';
import { analyticsRouter } from './features/analytics/analytics.routes';
import { notificationRouter } from './features/notifications/notification.routes';
import { adminRouter } from './features/admin/admin.routes';

export function createApp() {
  const app = express();

  // ── Security headers (Helmet) ────────────────────────────────────────────
  // WHY: Sets security-related HTTP headers (X-Frame-Options, CSP, etc.)
  app.use(helmet());

  // ── CORS ─────────────────────────────────────────────────────────────────
  // WHY: Allow only the known frontend origin; deny all others.
  // This is part of the CSRF mitigation strategy (see Threat Model T2).
  app.use(
    cors({
      origin: process.env.FRONTEND_URL ?? 'http://localhost:5173',
      credentials: true, // Required for cookies (refresh token)
    }),
  );

  // ── Body parsing ─────────────────────────────────────────────────────────
  app.use(express.json({ limit: '10kb' })); // Size limit prevents large payload attacks
  app.use(express.urlencoded({ extended: true }));
  app.use(cookieParser());

  // ── Swagger UI (development only) ────────────────────────────────────────
  if (process.env.NODE_ENV !== 'production') {
    const swaggerDoc = YAML.load(path.join(__dirname, '../docs/openapi/openapi.yaml'));
    app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDoc));
  }

  // ── Health check (unauthenticated) ───────────────────────────────────────
  app.get('/health', (_req, res) => res.json({ status: 'ok', timestamp: new Date().toISOString() }));

  // ── API Routes ───────────────────────────────────────────────────────────
  // Versioned under /api/v1 to allow non-breaking future changes
  const apiRouter = express.Router();

  apiRouter.use('/auth', authRouter);
  apiRouter.use('/pantry', pantryRouter);
  apiRouter.use('/recipes', recipeRouter);
  apiRouter.use('/shopping-lists', shoppingListRouter);
  apiRouter.use('/analytics', analyticsRouter);
  apiRouter.use('/notifications', notificationRouter);
  apiRouter.use('/admin', adminRouter);

  app.use('/api/v1', apiRouter);

  // ── 404 handler (must be before error handler) ───────────────────────────
  app.use((_req, res) => {
    res.status(404).json({
      success: false,
      error: { code: 'NOT_FOUND', message: 'The requested endpoint does not exist.' },
    });
  });

  // ── Global Error Handler (MUST be last) ──────────────────────────────────
  // WHY LAST: Express identifies error handlers by their 4-parameter signature.
  // If registered before routes, it will never catch route errors.
  app.use(globalErrorHandler);

  return app;
}
